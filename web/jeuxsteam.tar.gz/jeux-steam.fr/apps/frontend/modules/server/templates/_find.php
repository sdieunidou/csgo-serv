   <div class="form_find">
      <form action="<?php echo url_for('@server_find') ?>" method="post">

      <table>
        <tr>
          <th><?php echo $form['ip']->renderLabel() ?></th>
          <td><?php echo $form['ip']->render() ?></td>

          <th><?php echo $form['port']->renderLabel() ?></th>
          <td><?php echo $form['port']->render() ?></td>

          <th><?php echo $form['map']->renderLabel() ?></th>
          <td><?php echo $form['map']->render() ?></td>
        </tr>

        <tr>
          <th><?php echo $form['hostname']->renderLabel() ?></th>
          <td><?php echo $form['hostname']->render() ?></td>

          <th><?php echo $form['game_id']->renderLabel() ?></th>
          <td><?php echo $form['game_id']->render() ?></td>

          <th><?php echo $form['password']->renderLabel() ?></th>
          <td><?php echo $form['password']->render() ?></td>
        </tr>

        <tr>
          <th><?php echo $form['players']->renderLabel() ?></th>
          <td><?php echo $form['players']->render() ?></td>

          <th><?php echo $form['maxplayer']->renderLabel() ?></th>
          <td><?php echo $form['maxplayer']->render() ?></td>

          <td colspan="2">
            <?php echo $form->renderHiddenFields(false) ?>
            <input type="submit" value="Rechercher" />
          </td>
        </tr>
      </table>
      </form>
    </div>