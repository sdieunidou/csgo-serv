<?php use_helper('I18N') ?>

<div class="indent2">

  <h3><span><span><strong><strong>Inscription</strong></strong></span></span></h3>

  Participez aux sites & aux forums<br /><br />

Grâce à votre compte, vous pourrez facilement participer à la vie du site : commenter les actualités, poster dans le forum, noter les téléchargements, proposer des infos !
Passez à la vitesse supérieure<br /><br />

En plus des espaces de discussions, vous pouvez être inscrit(e) à l'annuaire des membres du site. Ainsi, vous pourrez créer votre clan, participer à un des clans déjà existants, personnaliser votre profil et bien d'autres options !


			<div class="box2 border border1">
  <?php echo get_partial('sfGuardRegister/form', array('form' => $form)) ?>
			</div>

</div>