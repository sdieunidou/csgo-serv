while true; do ps -u root | grep php | wc -l; sleep 10; done
