<?php

/**
 * Server filter form base class.
 *
 * @package    jeuxsteam
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class BaseServerFormFilter extends BaseFormFilterDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'ip'          => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'port'        => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'isp'         => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'country'     => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'map'         => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'hostname'    => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'players'     => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'maxplayer'   => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'is_online'   => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'password'    => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'is_banned'   => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'last_online' => new sfWidgetFormFilterDate(array('from_date' => new sfWidgetFormDate(), 'to_date' => new sfWidgetFormDate(), 'with_empty' => false)),
      'game_id'     => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Game'), 'add_empty' => true)),
      'user_id'     => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('sfGuardUser'), 'add_empty' => true)),
      'slug'        => new sfWidgetFormFilterInput(),
      'created_at'  => new sfWidgetFormFilterDate(array('from_date' => new sfWidgetFormDate(), 'to_date' => new sfWidgetFormDate(), 'with_empty' => false)),
      'updated_at'  => new sfWidgetFormFilterDate(array('from_date' => new sfWidgetFormDate(), 'to_date' => new sfWidgetFormDate(), 'with_empty' => false)),
    ));

    $this->setValidators(array(
      'ip'          => new sfValidatorPass(array('required' => false)),
      'port'        => new sfValidatorSchemaFilter('text', new sfValidatorInteger(array('required' => false))),
      'isp'         => new sfValidatorPass(array('required' => false)),
      'country'     => new sfValidatorPass(array('required' => false)),
      'map'         => new sfValidatorPass(array('required' => false)),
      'hostname'    => new sfValidatorPass(array('required' => false)),
      'players'     => new sfValidatorSchemaFilter('text', new sfValidatorInteger(array('required' => false))),
      'maxplayer'   => new sfValidatorSchemaFilter('text', new sfValidatorInteger(array('required' => false))),
      'is_online'   => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'password'    => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'is_banned'   => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'last_online' => new sfValidatorDateRange(array('required' => false, 'from_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 00:00:00')), 'to_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 23:59:59')))),
      'game_id'     => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('Game'), 'column' => 'id')),
      'user_id'     => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('sfGuardUser'), 'column' => 'id')),
      'slug'        => new sfValidatorPass(array('required' => false)),
      'created_at'  => new sfValidatorDateRange(array('required' => false, 'from_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 00:00:00')), 'to_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 23:59:59')))),
      'updated_at'  => new sfValidatorDateRange(array('required' => false, 'from_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 00:00:00')), 'to_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 23:59:59')))),
    ));

    $this->widgetSchema->setNameFormat('server_filters[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Server';
  }

  public function getFields()
  {
    return array(
      'id'          => 'Number',
      'ip'          => 'Text',
      'port'        => 'Number',
      'isp'         => 'Text',
      'country'     => 'Text',
      'map'         => 'Text',
      'hostname'    => 'Text',
      'players'     => 'Number',
      'maxplayer'   => 'Number',
      'is_online'   => 'Boolean',
      'password'    => 'Boolean',
      'is_banned'   => 'Boolean',
      'last_online' => 'Date',
      'game_id'     => 'ForeignKey',
      'user_id'     => 'ForeignKey',
      'slug'        => 'Text',
      'created_at'  => 'Date',
      'updated_at'  => 'Date',
    );
  }
}
