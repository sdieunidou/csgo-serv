<?php

/**
 * sfFacebookGraphUserProfile filter form base class.
 *
 * @package    jeuxsteam
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class BasesfFacebookGraphUserProfileFormFilter extends BaseFormFilterDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'user_id'                => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('User'), 'add_empty' => true)),
      'full_name'              => new sfWidgetFormFilterInput(),
      'user_set_name'          => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'facebook_uid'           => new sfWidgetFormFilterInput(),
      'access_token'           => new sfWidgetFormFilterInput(),
      'user_set_email_address' => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'facebook_only_account'  => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
    ));

    $this->setValidators(array(
      'user_id'                => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('User'), 'column' => 'id')),
      'full_name'              => new sfValidatorPass(array('required' => false)),
      'user_set_name'          => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'facebook_uid'           => new sfValidatorSchemaFilter('text', new sfValidatorInteger(array('required' => false))),
      'access_token'           => new sfValidatorPass(array('required' => false)),
      'user_set_email_address' => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'facebook_only_account'  => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
    ));

    $this->widgetSchema->setNameFormat('sf_facebook_graph_user_profile_filters[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'sfFacebookGraphUserProfile';
  }

  public function getFields()
  {
    return array(
      'id'                     => 'Number',
      'user_id'                => 'ForeignKey',
      'full_name'              => 'Text',
      'user_set_name'          => 'Boolean',
      'facebook_uid'           => 'Number',
      'access_token'           => 'Text',
      'user_set_email_address' => 'Boolean',
      'facebook_only_account'  => 'Boolean',
    );
  }
}
