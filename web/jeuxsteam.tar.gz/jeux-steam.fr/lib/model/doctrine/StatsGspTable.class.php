<?php


class StatsGspTable extends Doctrine_Table
{
    
    public static function getInstance()
    {
        return Doctrine_Core::getTable('StatsGsp');
    }
}