<?php


class sfFacebookGraphUserProfileTable extends PluginsfFacebookGraphUserProfileTable
{
    
    public static function getInstance()
    {
        return Doctrine_Core::getTable('sfFacebookGraphUserProfile');
    }
}