<?php
/**
 */
class PluginsfGuardForgotPasswordTable extends Doctrine_Table
{

}