<?php

/**
 * PluginsfFacebookGraphUserProfile form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage filter
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: PluginsfFacebookGraphUserProfileFormFilter.class.php 49 2010-05-25 18:11:19Z kevin $
 */
abstract class PluginsfFacebookGraphUserProfileFormFilter extends BasesfFacebookGraphUserProfileFormFilter
{
}
