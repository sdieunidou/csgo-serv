<?php

/**
 * PluginsfFacebookGraphUserProfile form.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage form
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: PluginsfFacebookGraphUserProfileForm.class.php 49 2010-05-25 18:11:19Z kevin $
 */
abstract class PluginsfFacebookGraphUserProfileForm extends BasesfFacebookGraphUserProfileForm
{
}
