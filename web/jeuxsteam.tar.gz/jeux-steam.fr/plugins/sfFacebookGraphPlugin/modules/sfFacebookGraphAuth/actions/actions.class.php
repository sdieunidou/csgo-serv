<?php

require_once(dirname(__FILE__).'/../lib/BasesfFacebookGraphAuthActions.class.php');

class sfFacebookGraphAuthActions extends BasesfFacebookGraphAuthActions
{
}