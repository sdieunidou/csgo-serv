<?php

class sfFacebookGraphDemoActions extends sfActions
{
  public function executeIndex($request)
  {
    $this->setLayout(false);
  }

  public function executeAsync($request)
  {
    $this->setLayout(false);
  }
}