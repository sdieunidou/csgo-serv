<?php
if(!defined('PCiMWHKGB5lwUwCci'))exit();
set_time_limit(30*60*60);
echo 'Analysis in progress...';flush();
if($mB38DEhdYf)
$K8zTIUVnwPDUDC = split("[\r\n]+",$mB38DEhdYf);
$PtUafGiAPeMBNuKQpDm = basename($grab_parameters['xs_smname']);
$aWjpeZhY_qaCTTKmvy = $grab_parameters['xs_compress']? '.gz':'';
$uv0LKrNpy = T_IVB6tYAThxWS.$PtUafGiAPeMBNuKQpDm.$aWjpeZhY_qaCTTKmvy;
$vqwWkTUJajn2Dj = T_IVB6tYAThxWS.$PtUafGiAPeMBNuKQpDm.'.proc';
preg_match('#(.*?//[^/]*)#',$grab_parameters['xs_initurl'],$tm);
$KkIiDw6iHW1n4Sy=$tm[1];
$Sd_5PqYOkY = '\w\d\.\,\-\/\!\(\) \_\[\]';
if(file_exists($vqwWkTUJajn2Dj) && filemtime($vqwWkTUJajn2Dj)>filemtime($uv0LKrNpy)){
list($eivnFROHnEo0qZ,$DpcfJunW664lc,$XjWSHkCxWdmWWs) = @unserialize(o5dbZtmDCSktjDlJt3($vqwWkTUJajn2Dj));
}else{
$cn='';
for($i=0;file_exists($dA8T7ubjCXUZ2=T_IVB6tYAThxWS.HlywPDappbdYVU($i,$PtUafGiAPeMBNuKQpDm).$aWjpeZhY_qaCTTKmvy);$i++)
{
$cn .= $aWjpeZhY_qaCTTKmvy?implode('',gzfile($dA8T7ubjCXUZ2)):o5dbZtmDCSktjDlJt3($dA8T7ubjCXUZ2);
}
preg_match_all('#<loc>(.*?)</loc>#',$cn,$um);
$pZraQah5aJyN = $um[1];
$eivnFROHnEo0qZ=$DpcfJunW664lc=$XjWSHkCxWdmWWs=array();
for($i=0;$i<count($pZraQah5aJyN);$i++){
$aQ4ElPDMjZqlA6eve = str_replace($KkIiDw6iHW1n4Sy,'',$pZraQah5aJyN[$i]);
fEowzoe6xJLhs_ZF4V7($aQ4ElPDMjZqlA6eve);
if(preg_match('#[^'.$Sd_5PqYOkY.']#',$aQ4ElPDMjZqlA6eve))
$XjWSHkCxWdmWWs[]=$aQ4ElPDMjZqlA6eve;


}
sort($XjWSHkCxWdmWWs);
$wc = serialize(array($eivnFROHnEo0qZ,$DpcfJunW664lc,$XjWSHkCxWdmWWs));
$pf=fopen($vqwWkTUJajn2Dj,'w');fwrite($pf,$wc);fclose($pf);
@chmod($vqwWkTUJajn2Dj, 0666);
}
if($lNALvVhch9wG)return;
echo 'DONE<br>';
?><pre>
<script>
function X5pGy9XVxZmKajMLt(eln)
{
el=document.getElementById('sp'+eln);
el.style.display=el.style.display?'':'none';
}
</script>
<?php


$V8LkdUr76kWKRNwEM8b = 1;
function e6rLElc7C4($sl,$ICfKWr5QeaWZ6O=0,$glOeIGW0kAmtf3vDSop='',$oHXaaeWlrm8J5445=true){
global $V8LkdUr76kWKRNwEM8b;
echo '<span id="sp'.($V8LkdUr76kWKRNwEM8b++).'"'.($ICfKWr5QeaWZ6O>2?' style="display:none"':'').'>';
ksort($sl);
$ls = $ICfKWr5QeaWZ6O*2;
foreach($sl as $sk=>$sn){

echo str_repeat(' ',$ls).
($sn['elem']?'<a href="javascript:X5pGy9XVxZmKajMLt(\''.$V8LkdUr76kWKRNwEM8b.'\')">[x]</a>':'').
($oHXaaeWlrm8J5445?'<a href="'.$glOeIGW0kAmtf3vDSop.$sk.'">'.$sk.'</a>':$sk).
str_repeat(' ',max(0,30-$ls-strlen($sk))).' - '.$sn['cnt'].($sn['tcnt']>$sn['cnt']?' ('.$sn['tcnt'].')':'')."\n";
if($sn['elem'])
e6rLElc7C4($sn['elem'],$ICfKWr5QeaWZ6O+1,$glOeIGW0kAmtf3vDSop.$sk,$oHXaaeWlrm8J5445);
}
echo '</span>';
}
e6rLElc7C4(array('Custom groups'=>$DpcfJunW664lc),0,$KkIiDw6iHW1n4Sy,false);
e6rLElc7C4($eivnFROHnEo0qZ['elem'],0,$KkIiDw6iHW1n4Sy);
foreach($XjWSHkCxWdmWWs as $ns){
preg_match_all('#([^'.$Sd_5PqYOkY.'])#',$ns,$mt);
$bcbDDxdnq=array_merge($bcbDDxdnq,$mt[1]);
}
$bcbDDxdnq = array_unique($bcbDDxdnq);
?>
</pre>
<h4>non-standard formatted urls (<?php echo count($XjWSHkCxWdmWWs)?>)</h4>
<?php
sort($bcbDDxdnq);
echo count($bcbDDxdnq).' : '.implode(' | ',$bcbDDxdnq).'<br>';
echo implode('<br>',$XjWSHkCxWdmWWs);
function fEowzoe6xJLhs_ZF4V7($dEiGIYwo7Srq3X){
global $eivnFROHnEo0qZ,$DpcfJunW664lc,$K8zTIUVnwPDUDC;
for($i=0;$i<count($K8zTIUVnwPDUDC);$i++)
if(preg_match('#'.$K8zTIUVnwPDUDC[$i].'#',$dEiGIYwo7Srq3X)){
$DpcfJunW664lc['elem'][$K8zTIUVnwPDUDC[$i]]['cnt']++;
$DpcfJunW664lc['tcnt']++;
break;
}
$I4xiiY8U2FMQjtAUzNB = &$eivnFROHnEo0qZ;
$psf7nhFBQzfQO7 = $dEiGIYwo7Srq3X;
$lv = 0;
while(($ps=strpos($dEiGIYwo7Srq3X,'/'))!==false){
$ns=substr($dEiGIYwo7Srq3X,0,$ps+1);
$I4xiiY8U2FMQjtAUzNB = &$I4xiiY8U2FMQjtAUzNB['elem'][$ns];
$I4xiiY8U2FMQjtAUzNB['tcnt']++;
$dEiGIYwo7Srq3X=substr($dEiGIYwo7Srq3X,$ps+1);
}
$I4xiiY8U2FMQjtAUzNB['cnt']++;
$I4xiiY8U2FMQjtAUzNB['pages'][] = $psf7nhFBQzfQO7;
}
?>