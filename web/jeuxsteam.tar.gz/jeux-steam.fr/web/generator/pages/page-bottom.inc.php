<br style="clear:both;"/>
</div>
<div id="copyright">
<?php include ZR1vtYkW3IIT6ji.'page-generator.inc.php';?>
<!--<?php echo hFdFC9FutftfbQcPCF;?>-->
Standalone Sitemap Generator (PHP) v<?php echo $RrdMupUEihGpaCVq['version']?>, <?php echo $RrdMupUEihGpaCVq['lastupdate']?>
|
<a href="license.html">Read License</a>
<?php echo $_SESSION['is_admin']?' | <a href="index.'.$muP565NgXyQ.'?op=logout">Logout</a>':'';?>
<?php if($grab_parameters['xs_checkver']){?>
<script type="text/javascript" src="http://www.xml-sitemaps.com/check-version.js?ver=<?php echo $RrdMupUEihGpaCVq['version'];?>"></script>
<?php } ?>
<br>
Copyright (c)2005-2010 <a href="http://www.xml-sitemaps.com">XML Sitemaps</a>
<br style="clear:both;"/>
</div>
</body>
</html>