<?php
include ZR1vtYkW3IIT6ji.'page-top.inc.php';
$aPeIhzjYj6iZvV = V15cq9dPNt8iS8();
$zmYRRBiNHXyzAGsBbH = array_pop($aPeIhzjYj6iZvV);
$qcHvzZE_cTnCJcmS = @unserialize(o5dbZtmDCSktjDlJt3(T_IVB6tYAThxWS.$zmYRRBiNHXyzAGsBbH));
?>
<div id="maincont">
<h2>External Links</h2>
<table>
<tr class=block1head>
<th>No</th>
<th>External Link</th>
<th>Referred From</th>
</tr>
<?php foreach($qcHvzZE_cTnCJcmS['urls_ext'] as $ue=>$CMQaGmG6s9sCBhxq){
?>
<tr class=block1>
<td><?php echo $i+1?></td>
<td><a href="<?php echo $ue?>"><?php echo $ue?></a></td>
<td><a href="<?php echo $qcHvzZE_cTnCJcmS['initdir']?><?php echo $CMQaGmG6s9sCBhxq?>"><?php echo $CMQaGmG6s9sCBhxq?></a></td>
</tr>
<?php }?>
</table>
</div>
<?php
include ZR1vtYkW3IIT6ji.'page-bottom.inc.php';
?>