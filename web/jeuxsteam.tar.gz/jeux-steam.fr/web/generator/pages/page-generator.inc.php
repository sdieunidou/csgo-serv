<?php
$RrdMupUEihGpaCVq = array(
'version'=>'4.0',
'lastupdate'=>'2010-05-20',
'link'=>'http://www.xml-sitemaps.com/news-20100520.html'
);
?>