<?php
switch($wNuDcYNWIWQ){
case 'gz':
$w21UPtIuo5RB0Crs = o5dbZtmDCSktjDlJt3(T_IVB6tYAThxWS.'sitemap.xml');
yvOIe0tV6y4KcO0aLl('sitemap.xml', $w21UPtIuo5RB0Crs, T_IVB6tYAThxWS, true);
break;
}
?>