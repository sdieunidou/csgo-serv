<?php
if(!defined('PCiMWHKGB5lwUwCci'))exit();
$aPeIhzjYj6iZvV = V15cq9dPNt8iS8();
if(count($aPeIhzjYj6iZvV)>0){
$zmYRRBiNHXyzAGsBbH = array_pop($aPeIhzjYj6iZvV);
@set_time_limit(60*60);
$qcHvzZE_cTnCJcmS = @unserialize(o5dbZtmDCSktjDlJt3(T_IVB6tYAThxWS.$zmYRRBiNHXyzAGsBbH));
if(filesize(T_IVB6tYAThxWS.$zmYRRBiNHXyzAGsBbH)>2000000)
{
$qcHvzZE_cTnCJcmS['newurls'] = $qcHvzZE_cTnCJcmS['losturls'] = $qcHvzZE_cTnCJcmS['aproc'] = array();
yvOIe0tV6y4KcO0aLl($zmYRRBiNHXyzAGsBbH,serialize($qcHvzZE_cTnCJcmS));
}
?>
<div class="block1head">
Sitemap details
</div>
<div class="block1">
<b>Request date:</b><br>
<?php echo date('j F Y, H:i',$qcHvzZE_cTnCJcmS['time'])?><br>
<b>Processing time:</b><br>
<?php echo Yqz1QyXnf8Zlfu9jU($qcHvzZE_cTnCJcmS['ctime'])?>s<br>
<b>Pages indexed:</b><br>
<?php echo $qcHvzZE_cTnCJcmS['ucount']?><br>
<b>Sitemap files:</b><br>
<?php echo count($qcHvzZE_cTnCJcmS['files'])?><br>
<b>Pages size:</b><br>
<?php echo number_format($qcHvzZE_cTnCJcmS['tsize']/1024/1024,2)?>Mb<br>
<b>Download:</b><br>
<a href="<?php echo $grab_parameters['xs_smurl'].$ZKHrdYpZx7xJpCetjV?>">XML sitemap</a>
<br/>
<a href="<?php echo a_swOP2hskJvhpi2o . $ZKHrdYpZx7xJpCetjV;?>">In text format</a>
<br/>
<a href="<?php echo u3Aj3kpP8f7NX ;?>">In ROR format</a>
<!--
<br/>
<a href="<?php echo duBMhqfH7kGKH . $ZKHrdYpZx7xJpCetjV;?>">In Google Base format</a>
-->
<br/>
<a href="<?php echo $grab_parameters['htmlurl']?>">HTML sitemap</a>
<br />
<?php
foreach($sm_proc_list as $bsdObbWFYcM20JyA)
if($grab_parameters[$bsdObbWFYcM20JyA->XvaJJE34XW])
echo '<br /><a href="'.$bsdObbWFYcM20JyA->KpqQMAo204oEII.'">'.$bsdObbWFYcM20JyA->IeJBGxA5o.'</a>';
?>
</div>
<?php if(count($qcHvzZE_cTnCJcmS['u404'])){
?>
<div class="block2head">
Broken links
</div>
<div class="block1">
<b><?php echo count($qcHvzZE_cTnCJcmS['u404'])?> broken links</b> found! 
<br><a href="index.<?php echo $muP565NgXyQ?>?op=l404">View the list</a>.
</div>
<?php
}
}else{
?>
<div class="block2head">
No sitemaps found
</div>
<div class="block1">
Sitemap was not generated yet, please go to <a href="index.<?php echo $muP565NgXyQ?>?op=crawl">Crawling</a>
page to start crawler manually or to setup a cron job.
</div>
<?php
}
?>
