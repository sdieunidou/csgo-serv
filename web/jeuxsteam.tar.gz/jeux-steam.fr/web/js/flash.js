$(document).ready(function()
{
  $('.notification .close').live('click', function ()
  {
    $(this).parent().fadeOut('slow');
  });
});